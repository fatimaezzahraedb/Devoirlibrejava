package bank;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

public class DecisionTest {

    @Test
    public void testGetTransaction() {
        // Arrange
        Bank bank = new Bank("BMC", "Maroc", "Azer");
        Customer customer = new Customer("jean","adresse 1","061234556");
        Account account = new Account(customer, bank, 20000);
        Bank bank2 = new Bank("BMC", "Alger", "Azere");
        Customer customer2 = new Customer("Dustin","adresse 2","061234556");
        Account account2 = new Account(customer2, bank2, 20000);
        Transaction transaction = new Transaction("12", new Date(), 1000, account, account2);
        Employee richard = new Employee("1","richard");
        Decision decision = new Decision(transaction, richard, true);

        // Act
        Transaction result = decision.getTransaction();

        // Assert
        assertEquals(transaction, result);
    }

    @Test
    public void testGetEmployee() {
        // Arrange
        Bank bank = new Bank("BMC", "Maroc", "Azer");
        Customer customer = new Customer("jean","adresse 1","061234556");
        Account account = new Account(customer, bank, 20000);
        Bank bank2 = new Bank("BMC", "Alger", "Azere");
        Customer customer2 = new Customer("Dustin","adresse 2","061234556");
        Account account2 = new Account(customer2, bank2, 20000);
        Transaction transaction = new Transaction("12", new Date(), 1000, account, account2);
        Employee richard = new Employee("1","richard");
        Decision decision = new Decision(transaction, richard, true);

        // Act
        Employee result = decision.getEmployees();

        // Assert
        assertEquals(richard, result);
    }

    @Test
    public void testGetType() {
        // Arrange
        Bank bank = new Bank("BMC", "Maroc", "Azer");
        Customer customer = new Customer("jean","adresse 1","061234556");
        Account account = new Account(customer, bank, 20000);
        Bank bank2 = new Bank("BMC", "Alger", "Azere");
        Customer customer2 = new Customer("Dustin","adresse 2","061234556");
        Account account2 = new Account(customer2, bank2, 20000);
        Transaction transaction = new Transaction("12", new Date(), 1000, account, account2);
        Employee richard = new Employee("1","richard");
        Decision decision = new Decision(transaction, richard, true);

        // Act
        Boolean result = decision.getType();

        // Assert
        assertTrue(result);
    }

    @Test
    public void testSetType() {
        // Arrange
        Bank bank = new Bank("BMC", "Maroc", "Azer");
        Customer customer = new Customer("jean","adresse 1","061234556");
        Account account = new Account(customer, bank, 20000);
        Bank bank2 = new Bank("BMC", "Alger", "Azere");
        Customer customer2 = new Customer("Dustin","adresse 2","061234556");
        Account account2 = new Account(customer2, bank2, 20000);
        Transaction transaction = new Transaction("12", new Date(), 1000, account, account2);
        Employee richard = new Employee("1","richard");
        Decision decision = new Decision(transaction, richard, true);

        // Act
        decision.setType(false);

        // Assert
        assertFalse(decision.getType());
    }

    @Test
    public void testToString() {
        // Arrange
        Bank bank = new Bank("BMC", "Maroc", "Azer");
        Customer customer = new Customer("jean","adresse 1","061234556");
        Account account = new Account(customer, bank, 20000);
        Bank bank2 = new Bank("BMC", "Alger", "Azere");
        Customer customer2 = new Customer("Dustin","adresse 2","061234556");
        Account account2 = new Account(customer2, bank2, 20000);
        Transaction transaction = new Transaction("12", new Date(), 1000, account, account2);
        Employee richard = new Employee("1","richard");
        Decision decision = new Decision(transaction, richard, true);

        // Act
        String result = decision.toString();

        // Assert
        assertTrue(result.contains("transaction=" + transaction.getId()));
        assertTrue(result.contains("employee=" + richard.getName()));
        assertTrue(result.contains("type=" + true));
    }
}
