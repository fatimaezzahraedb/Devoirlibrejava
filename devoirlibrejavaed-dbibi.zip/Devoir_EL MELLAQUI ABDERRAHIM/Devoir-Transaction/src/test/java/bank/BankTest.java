package bank;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BankTest {

    @Test
    public void testAddAccount() {
        // Arrange
        Bank bank = new Bank("Test Bank", "Test Country", "TEST123");
        Account account1 = new Account();
        Account account2 = new Account();

        // Act
        bank.addAccount(account1);
        bank.addAccount(account2);

        // Assert
        assertTrue(bank.getAccounts().contains(account1));
        assertTrue(bank.getAccounts().contains(account2));
    }

    @Test
    public void testGetAccounts() {
        // Arrange
        Bank bank = new Bank("Test Bank", "Test Country", "TEST123");
        Account account1 = new Account();
        Account account2 = new Account();
        bank.addAccount(account1);
        bank.addAccount(account2);

        // Act
        List<Account> accounts = bank.getAccounts();

        // Assert
        assertEquals(2, accounts.size());
        assertTrue(accounts.contains(account1));
        assertTrue(accounts.contains(account2));
    }

    @Test
    public void testToString() {
        // Arrange
        Bank bank = new Bank("MyBank", "United States", "US123");
        Customer customer = new Customer("Alice Johnson", "123 Main St", "555-1234");
        Account account1 = new Account(customer, bank, 5000);
        Bank bank2 = new Bank("AnotherBank", "Canada", "CA456");
        Customer customer2 = new Customer("Bob Smith", "456 Oak St", "555-5678");
        Account account2 = new Account(customer2, bank2, 8000);
        bank.addAccount(account1);
        bank.addAccount(account2);

        // Act
        String result = bank.toString();

        // Assert
        assertTrue(result.contains("Bank Name: MyBank"));
        assertTrue(result.contains("Country: United States"));
        assertTrue(result.contains("Bank Code: US123"));
        assertTrue(result.contains("Accounts:"));
    }
}
