package bank;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CustomerTest {

    @Test
    public void testGetName() {
        // Arrange
        Customer customer = new Customer("Alice Smith", "123 Oak St", "555-1234");

        // Act
        String result = customer.getName();

        // Assert
        assertEquals("Alice Smith", result);
    }

    @Test
    public void testSetName() {
        // Arrange
        Customer customer = new Customer();

        // Act
        customer.setName("Bob Johnson");

        // Assert
        assertEquals("Bob Johnson", customer.getName());
    }

    @Test
    public void testGetAddress() {
        // Arrange
        Customer customer = new Customer("Alice Smith", "123 Oak St", "555-1234");

        // Act
        String result = customer.getAddress();

        // Assert
        assertEquals("123 Oak St", result);
    }

    @Test
    public void testSetAddress() {
        // Arrange
        Customer customer = new Customer();

        // Act
        customer.setAddress("456 Pine St");

        // Assert
        assertEquals("456 Pine St", customer.getAddress());
    }

    @Test
    public void testGetPhoneNumber() {
        // Arrange
        Customer customer = new Customer("Alice Smith", "123 Oak St", "555-1234");

        // Act
        String result = customer.getPhoneNumber();

        // Assert
        assertEquals("555-1234", result);
    }

    @Test
    public void testSetPhoneNumber() {
        // Arrange
        Customer customer = new Customer();

        // Act
        customer.setPhoneNumber("987-654-3210");

        // Assert
        assertEquals("987-654-3210", customer.getPhoneNumber());
    }

    @Test
    public void testGetAccount() {
        // Arrange
        Customer customer = new Customer();

        // Act
        Account result = customer.getAccount();

        // Assert
        assertNotNull(result);
    }

    @Test
    public void testSetAccount() {
        // Arrange
        Customer customer = new Customer();
        Account newAccount = new Account();

        // Act
        customer.setAccount(newAccount);

        // Assert
        assertEquals(newAccount, customer.getAccount());
    }

    @Test
    public void testToString() {
        // Arrange
        Customer customer = new Customer("Alice Smith", "123 Oak St", "555-1234");

        // Act
        String result = customer.toString();

        // Assert
        assertTrue(result.contains("Name: Alice Smith"));
        assertTrue(result.contains("Address: 123 Oak St"));
        assertTrue(result.contains("Phone Number: 555-1234"));
        assertTrue(result.contains("Account Information:"));
    }
}
