package bank;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AccountTest {

    @Test
    public void testGetAccountNumber() {
        // Set up
        Account account = new Account();

        // Perform
        String result = account.getAccountNumber();

        // Verify
        assertNotNull(result);
    }

    @Test
    public void testGetCustomer() {
        // Set up
        Customer customer = new Customer("Alice Smith", "123 Main St", "987-654-3210");
        Account account = new Account(customer, new Bank(), 1500);

        // Perform
        Customer result = account.getCustomer();

        // Verify
        assertEquals(customer, result);
    }

    @Test
    public void testGetBank() {
        // Set up
        Bank bank = new Bank("New Test Bank", "New Test Country", "NEWTEST123");
        Account account = new Account(new Customer(), bank, 2000);

        // Perform
        Bank result = account.getBank();

        // Verify
        assertEquals(bank, result);
    }

    @Test
    public void testGetBalance() {
        // Set up
        Account account = new Account(new Customer(), new Bank(), 2500);

        // Perform
        double result = account.getBalance();

        // Verify
        assertEquals(2500, result, 0.01);
    }

    @Test
    public void testSetBalance() {
        // Set up
        Account account = new Account(new Customer(), new Bank(), 3000);

        // Perform
        account.setBalance(4000);

        // Verify
        assertEquals(4000, account.getBalance(), 0.01);
    }

    @Test
    public void testDeposit() {
        // Set up
        Account account = new Account(new Customer(), new Bank(), 5000);

        // Perform
        account.deposit(1000);

        // Verify
        assertEquals(6000, account.getBalance(), 0.01);
    }

    @Test
    public void testToString() {
        // Set up
        Customer customer = new Customer("Bob Johnson", "456 Oak St", "555-123-4567");
        Bank bank = new Bank("Another Test Bank", "Another Test Country", "ANOTHERTEST123");
        Account account = new Account(customer, bank, 3000);

        // Perform
        String result = account.toString();

        // Verify
        assertTrue(result.contains("Account Number:"));
        assertTrue(result.contains("Customer: Bob Johnson"));
        assertTrue(result.contains("Bank: Another Test Bank"));
        assertTrue(result.contains("Balance: $3000.0"));
    }
}
