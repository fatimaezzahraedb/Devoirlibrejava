package bank;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TransactionTest {

    @Test
    public void transactionTypeIsVirInt() {
        Bank bank = new Bank("ABC Bank", "France", "ABC123");
        Customer customer = new Customer("Alice", "123 Main St", "987-654-3210");
        Account account = new Account(customer, bank, 25000);
        Bank bank2 = new Bank("XYZ Bank", "Germany", "XYZ789");
        Customer customer2 = new Customer("Bob", "456 Oak St", "123-456-7890");
        Account account2 = new Account(customer2, bank2, 30000);
        Transaction transaction = new Transaction("ABC123", new Date(), 1500, account, account2);
        // 2 accounts are from the same bank => VirInt
        assertEquals("VirInt", transaction.getTransactionType());
    }

    @Test
    public void transactionTypeIsVirCha() {
        Bank bank = new Bank("ABC Bank", "France", "ABC123");
        Customer customer = new Customer("Alice", "123 Main St", "987-654-3210");
        Account account = new Account(customer, bank, 25000);
        Bank bank2 = new Bank("CIH Bank", "Morocco", "CIH456");
        Customer customer2 = new Customer("Bob", "456 Oak St", "123-456-7890");
        Account account2 = new Account(customer2, bank2, 30000);
        Transaction transaction = new Transaction("XYZ789", new Date(), 2000, account, account2);

        assertEquals("VirCha", transaction.getTransactionType());
    }

    @Test
    public void transactionTypeIsVirEst() {
        Bank bank = new Bank("ABC Bank", "France", "ABC123");
        Customer customer = new Customer("Alice", "123 Main St", "987-654-3210");
        Account account = new Account(customer, bank, 25000);
        Bank bank2 = new Bank("American Bank", "USA", "AM123");
        Customer customer2 = new Customer("Bob", "456 Oak St", "123-456-7890");
        Account account2 = new Account(customer2, bank2, 30000);
        Transaction transaction = new Transaction("DEF456", new Date(), 3000, account, account2);

        assertEquals("VirEst", transaction.getTransactionType());
    }

    @Test
    public void virIntTransactionIsAllowedWithOneValidator() {
        Bank bank = new Bank("ABC Bank", "France", "ABC123");
        Customer customer = new Customer("Alice", "123 Main St", "987-654-3210");
        Account account = new Account(customer, bank, 25000);
        Bank bank2 = new Bank("ABC Bank", "France", "ABC123");
        Customer customer2 = new Customer("Bob", "456 Oak St", "123-456-7890");
        Account account2 = new Account(customer2, bank2, 30000);
        Transaction transaction = new Transaction("ABC123", new Date(), 1500, account, account2);
        Employee richard = new Employee("1", "Richard");
        Employee sam = new Employee("2", "Sam");
        Employee john = new Employee("3", "John");
        Decision decision1 = new Decision(transaction, sam, true);
        Decision decision2 = new Decision(transaction, sam, false);
        Decision decision3 = new Decision(transaction, john, false);
        transaction.addDecision(decision1);
        transaction.addDecision(decision2);
        transaction.addDecision(decision3);
        assertTrue(transaction.getIsAllowed());
    }

    @Test
    public void virChaTransactionIsAllowedWithTwoValidators() {
        Bank bank = new Bank("ABC Bank", "France", "ABC123");
        Customer customer = new Customer("Alice", "123 Main St", "987-654-3210");
        Account account = new Account(customer, bank, 25000);
        Bank bank2 = new Bank("CIH Bank", "Morocco", "CIH456");
        Customer customer2 = new Customer("Bob", "456 Oak St", "123-456-7890");
        Account account2 = new Account(customer2, bank2, 30000);
        Transaction transaction = new Transaction("XYZ789", new Date(), 2000, account, account2);
        Employee richard = new Employee("1", "Richard");
        Employee sam = new Employee("2", "Sam");
        Employee john = new Employee("3", "John");
        Decision decision1 = new Decision(transaction, sam, true);
        Decision decision2 = new Decision(transaction, sam, true);
        Decision decision3 = new Decision(transaction, john, false);
        transaction.addDecision(decision1);
        transaction.addDecision(decision2);
        transaction.addDecision(decision3);
        assertTrue(transaction.getIsAllowed());
    }

    @Test
    public void virChaTransactionIsNotAllowedWithOneValidator() {
        Bank bank = new Bank("ABC Bank", "France", "ABC123");
        Customer customer = new Customer("Alice", "123 Main St", "987-654-3210");
        Account account = new Account(customer, bank, 25000);
        Bank bank2 = new Bank("CIH Bank", "Morocco", "CIH456");
        Customer customer2 = new Customer("Bob", "456 Oak St", "123-456-7890");
        Account account2 = new Account(customer2, bank2, 30000);
        Transaction transaction = new Transaction("XYZ789", new Date(), 2000, account, account2);
        Employee richard = new Employee("1", "Richard");
        Employee sam = new Employee("2", "Sam");
        Employee john = new Employee("3", "John");
        Decision decision1 = new Decision(transaction, sam, true);
        Decision decision2 = new Decision(transaction, sam, false);
        Decision decision3 = new Decision(transaction, john, false);
        transaction.addDecision(decision1);
        transaction.addDecision(decision2);
        transaction.addDecision(decision3);
        assertFalse(transaction.getIsAllowed());
    }

    @Test
    public void virEstTransactionIsAllowedWithThreeValidators() {
        Bank bank = new Bank("ABC Bank", "France", "ABC123");
        Customer customer = new Customer("Alice", "123 Main St", "987-654-3210");
        Account account = new Account(customer, bank, 25000);
        Bank bank2 = new Bank("American Bank", "USA", "AM123");
        Customer customer2 = new Customer("Bob", "456 Oak St", "123-456-7890");
        Account account2 = new Account(customer2, bank2, 30000);
        Transaction transaction = new Transaction("DEF456", new Date(), 3000, account, account2);
        Employee richard = new Employee("1", "Richard");
        Employee sam = new Employee("2", "Sam");
        Employee john = new Employee("3", "John");
        Decision decision1 = new Decision(transaction, sam, true);
        Decision decision2 = new Decision(transaction, sam, true);
        Decision decision3 = new Decision(transaction, john, true);
        transaction.addDecision(decision1);
        transaction.addDecision(decision2);
        transaction.addDecision(decision3);
        assertTrue(transaction.getIsAllowed());
    }

    @Test
    public void virEstTransactionIsNotAllowedWithTwoValidators() {
        Bank bank = new Bank("ABC Bank", "France", "ABC123");
        Customer customer = new Customer("Alice", "123 Main St", "987-654-3210");
        Account account = new Account(customer, bank, 25000);
        Bank bank2 = new Bank("American Bank", "USA", "AM123");
        Customer customer2 = new Customer("Bob", "456 Oak St", "123-456-7890");
        Account account2 = new Account(customer2, bank2, 30000);
        Transaction transaction = new Transaction("DEF456", new Date(), 3000, account, account2);
        Employee richard = new Employee("1", "Richard");
        Employee sam = new Employee("2", "Sam");
        Employee john = new Employee("3", "John");
        Decision decision1 = new Decision(transaction, sam, true);
        Decision decision2 = new Decision(transaction, sam, true);
        Decision decision3 = new Decision(transaction, john, false);
        transaction.addDecision(decision1);
        transaction.addDecision(decision2);
        transaction.addDecision(decision3);
        assertFalse(transaction.getIsAllowed());
    }
}
