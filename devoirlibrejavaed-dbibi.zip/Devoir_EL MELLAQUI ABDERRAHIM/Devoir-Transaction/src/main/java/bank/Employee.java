package bank;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;

public class Employee {
    private final String employeeId;
    private final String name;
    private List<Decision> decisions = new ArrayList<Decision>();

    // Constructor
    public Employee(String employeeId, String name) {
        this.employeeId = employeeId;
        this.name = name;
    }

    // Getter for employee ID
    public String getEmployeeId() {
        return employeeId;
    }

    // Getter for employee name
    public String getName() {
        return name;
    }

    public List<Decision> getDecisions() {
        return this.decisions; // Use clone to provide a defensive copy
    }

    // Setter for decisions
    public void addDecision(Decision decision) {
        this.decisions.add(decision);
    }
    public String toJson() {
        ObjectMapper objectMapper = new ObjectMapper();
        try{
            return objectMapper.writeValueAsString(this);
        }catch(JsonProcessingException e){
            e.printStackTrace();
        }
        return null;
    }

    // Get a string representation of the employee
    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Employee ID: ").append(employeeId).append("\n");
        stringBuilder.append("Name: ").append(name).append("\n");

        // Append information about each decision
        stringBuilder.append("Decisions:\n");
        for (Decision decision : decisions) {
            stringBuilder.append(decision.toString()).append("\n");
        }

        return stringBuilder.toString();
    }
}
