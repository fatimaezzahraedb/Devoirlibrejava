package bank;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;

public class Bank {
    private String name;
    private String country;
    private String bankCode;
    private List<Account> accounts = new ArrayList<Account>();

    // Constructor
    public Bank() {
        super();
    }
    public Bank(String name, String country, String bankCode) {
        this.name = name;
        this.country = country;
        this.bankCode = bankCode;
    }

    // Getters and setters for bank information
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }
    public List<Account> getAccounts(){
        return accounts;
    }
    public void addAccount(Account account){
        this.accounts.add(account);
    }
    public String toJson() {
        ObjectMapper objectMapper = new ObjectMapper();
        try{
            return objectMapper.writeValueAsString(this);
        }catch(JsonProcessingException e){
            e.printStackTrace();
        }
        return null;
    }

    // Get a string representation of the bank
    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Bank Name: ").append(name).append("\n");
        stringBuilder.append("Country: ").append(country).append("\n");
        stringBuilder.append("Bank Code: ").append(bankCode).append("\n");
        stringBuilder.append("Accounts:\n");

        for (Account account : accounts) {
            stringBuilder.append(account.getAccountNumber()).append("\n");
        }

        return stringBuilder.toString();
    }
}
