package bank;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Customer {
    private String name;
    private String address;
    private String phoneNumber;
    private Account account=new Account();

    public Customer(){
        super();
    }
    public Customer(String name, String address, String phoneNumber) {
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    // Getters and setters for customer information
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Account getAccount() {
        return this.account;
    }
    public void setAccount(Account account){
        this.account = account;
    }
    public String toJson() {
        ObjectMapper objectMapper = new ObjectMapper();
        try{
            return objectMapper.writeValueAsString(this);
        }catch(JsonProcessingException e){
            e.printStackTrace();
        }
        return null;
    }
    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Name: ").append(name).append("\n");
        stringBuilder.append("Address: ").append(address).append("\n");
        stringBuilder.append("Phone Number: ").append(phoneNumber).append("\n");
        stringBuilder.append("Account Information:\n");
        if(account!=null) {
        stringBuilder.append(account.getAccountNumber()).append("\n");
        }
        return stringBuilder.toString();
    }
}