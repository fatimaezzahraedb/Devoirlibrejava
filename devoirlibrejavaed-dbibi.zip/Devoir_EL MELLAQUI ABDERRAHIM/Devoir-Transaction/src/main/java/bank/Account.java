package bank;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.UUID;

public class Account {
    private final String accountNumber = generateAccountNumber();
    private Customer customer;
    private Bank bank = new Bank();
    private double balance;

    public Account(){
        super();
    }
    public Account(Customer customer, Bank bank, double initialBalance) {
        this.customer = customer;
        this.bank = bank;
        this.balance = initialBalance;
    }

    private String generateAccountNumber() {
        // Generate a unique account number (You can use your own logic)
        return UUID.randomUUID().toString();
    }

    // Getters and setters for account information
    public String getAccountNumber() {
        return this.accountNumber;
    }

    public Customer getCustomer() {
        return this.customer;
    }

    public Bank getBank() {
        return this.bank;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    // Deposit money into the account
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }

    // Transfer money from this account to another account
   /*public void transfer(Account recipientAccount, double amount) {
        if (amount > 0 && amount <= balance) {//add validators condition
            balance -= amount;
            recipientAccount.deposit(amount);
        }
    }

    */

    // Get a string representation of the account
    public String toJson() {
        ObjectMapper objectMapper = new ObjectMapper();
        try{
            return objectMapper.writeValueAsString(this);
        }catch(JsonProcessingException e){
            e.printStackTrace();
        }
        return null;
    }
    @Override
    public String toString() {
        return "Account Number: " + accountNumber + "\n" +
                "Customer: " + customer.getName() + "\n" +
                "Bank: " + bank.getName() + "\n" +
                "Balance: $" + balance;
    }
}
