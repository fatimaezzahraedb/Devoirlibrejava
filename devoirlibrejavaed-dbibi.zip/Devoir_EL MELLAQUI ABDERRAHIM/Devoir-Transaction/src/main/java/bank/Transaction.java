package bank;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Transaction {
    private String Id;
    private Date date;
    private double amount;
    private Account debit;
    private Account credit;
    private List<Decision> decisions = new ArrayList<Decision>();
    private boolean isAllowed;
    private String transactionType;

    // Constructor
    public Transaction(){
        super();
    }
    public Transaction(String Id, Date date, double amount, Account debit, Account credit) {
        this.Id = Id;
        this.date = date;
        this.amount = amount;
        this.debit = debit;
        this.credit = credit;
        this.transactionType = getType();
        this.isAllowed = allowTransaction();

    }

    // getType(): Method to determine the transaction type based on accounts
    private String getType() {
        // VirInt: same bank code
        // VirCha: same country different bank codes
        // VirEst: different Countries
        if (this.debit.getBank().getBankCode().equals(this.credit.getBank().getBankCode())) {
            return "VirInt";
        } else if (this.debit.getBank().getCountry().equals(this.credit.getBank().getCountry())) {
            return "VirCha";
        } else {
            return "VirEst";
        }
    }

    // Getters for transaction information
    public String getId() {
        return Id;
    }

    public Date getDate() {
        return date;
    }

    public double getAmount() {
        return amount;
    }

    public Account getDebit() {
        return debit;
    }

    public Account getCredit() {
        return credit;
    }
    public List<Decision> getDecisions() {
        return decisions;
    }

    //When we add or set decisions, we need to recheck if it is allowed again
    public void setDecisions(List<Decision> decisions) {
        this.decisions = decisions;
        this.isAllowed=allowTransaction();
    }
    public void addDecision(Decision decision) {
        this.decisions.add(decision);
        this.isAllowed=allowTransaction();
    }

    public boolean getIsAllowed() {
        return isAllowed;
    }

    private boolean allowTransaction() {
        /*

        we allow the transaction if:
        for Virint:
            if  ammount < 1Million: 1 validator
            else : 2 validators
        for VirCha:
            if ammount<100k: 2validators
            else : 3 validators
        for VirEst:
            if ammount<5k: 2validators
            else: 3 validators
        */
        int validators = 0;//number of validators
        for (int i = 0; i < this.decisions.size(); i++) {
            if (this.decisions.get(i).getType()) {//if the decision is "yes(allow)"
                validators += 1;
            }
        }
        if(this.transactionType.equals("VirInt")){
            //!!!! add conditions for each Vir!!!!
            if(this.amount<1000000){
                return validators >= 1;
            }
            else return validators >= 2;
        }
        if(this.transactionType.equals("VirCha")){
            //!!!! add conditions for each Vir!!!!
            if(this.amount<100000){
                 return validators >= 2;
            }
            else return validators >= 3;
        }
        if(this.transactionType.equals("VirEst")){
            //!!!! add conditions for each Vir!!!!
            if(this.amount<5000){
                return validators >= 2;
            }
            else return validators >= 3;
        }

        return false; //au cas où aucune des if n'est realisée (pb de frappe ...)
    }

    public String getTransactionType() {
        return transactionType;
    }
    public String toJson() {
        ObjectMapper objectMapper = new ObjectMapper();
        try{
            return objectMapper.writeValueAsString(this);
        }catch(JsonProcessingException e){
            e.printStackTrace();
        }
        return null;
    }

    // Get a string representation of the transaction
    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Transaction ID: ").append(Id).append("\n");
        stringBuilder.append("Date: ").append(date).append("\n");
        stringBuilder.append("Amount: $").append(amount).append("\n");
        stringBuilder.append("Debit Account: ").append(debit.getAccountNumber()).append("\n");
        stringBuilder.append("Credit Account: ").append(credit.getAccountNumber()).append("\n");
        stringBuilder.append("Transaction Type: ").append(transactionType).append("\n");
        stringBuilder.append("Is Allowed: ").append(isAllowed).append("\n");

        // Append information about each decision
        stringBuilder.append("Decisions:\n");
        for (Decision decision : decisions) {
            stringBuilder.append(decision.toString()).append("\n");
        }

        return stringBuilder.toString();
    }
}
