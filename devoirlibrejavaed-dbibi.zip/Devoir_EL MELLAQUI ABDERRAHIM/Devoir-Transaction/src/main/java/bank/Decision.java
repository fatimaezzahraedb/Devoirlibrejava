package bank;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Decision {
    private final Transaction transaction;
    private final Employee employee;
    private Boolean type;//allowed or not

    public Decision(Transaction transaction, Employee employee, Boolean type) {
        this.transaction = transaction;
        this.employee = employee;
        this.type = type;
    }

    // Getter for transaction
    public Transaction getTransaction() {
        return transaction;
    }

    // Getter for employees
    public Employee getEmployees() {
        return employee;
    }

    // Getter for type
    public Boolean getType() {
        return type;
    }

    // Setter for type
    public void setType(Boolean type) {
        this.type = type;
    }
    public String toJson() {
        ObjectMapper objectMapper = new ObjectMapper();
        try{
            return objectMapper.writeValueAsString(this);
        }catch(JsonProcessingException e){
            e.printStackTrace();
        }
        return null;
    }

    // toString method to represent the object as a string
    @Override
    public String toString() {
        return "Decision{" +
                "transaction=" + transaction.getId() +
                ", employee=" + employee.getName() +
                ", type=" + type +
                '}';
    }

}
