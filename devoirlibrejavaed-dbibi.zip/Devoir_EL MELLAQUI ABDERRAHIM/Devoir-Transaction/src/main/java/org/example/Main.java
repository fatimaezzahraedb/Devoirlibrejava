package org.example;
import bank.*;

import java.math.BigDecimal;
import java.util.Date;


public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank("BMC", "Maroc", "Azer");
        Customer customer = new Customer("jean","adresse 1","061234556");
        Account account = new Account(customer, bank, 20000);
        Bank bank2 = new Bank("BMC", "Alger", "Azere");
        Customer customer2 = new Customer("Dustin","adresse 2","061234556");
        Account account2 = new Account(customer2, bank2, 20000);
        Transaction transaction = new Transaction("12", new Date(), 1000, account, account2);
        Employee richard = new Employee("1","richard");
        Employee sam = new Employee("2", "sam");
        Employee john = new Employee("3", "john");
        Decision decision1 = new Decision(transaction, sam, true);
        Decision decision2 = new Decision(transaction, sam, false);
        Decision decision3 = new Decision(transaction, john, true);
        transaction.addDecision(decision1);
        transaction.addDecision(decision2);
        transaction.addDecision(decision3);

        System.out.println(transaction.toString());

    }
}